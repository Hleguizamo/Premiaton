<?php

namespace Cpdg\UsuarioBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class CpdgUsuarioBundle extends Bundle
{
}
